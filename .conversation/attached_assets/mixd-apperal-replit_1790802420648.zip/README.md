# MiXd Apperal

A small-batch streetwear storefront: home, shop (with filtering/sorting), a
product detail template, about, and contact — plus a working cart drawer.
Hand-drawn SVG product art, no build step, no external dependencies.

## Running on Replit

1. On [replit.com](https://replit.com), click **Create Repl → Import from
   upload** (or drag this folder/zip onto the Replit dashboard).
2. Replit will detect `package.json` and `.replit` automatically.
3. Click **Run**. The site starts at the URL Replit gives you (port 3000
   internally, mapped to the public URL).

No `npm install` is required — `server.js` only uses Node's built-in `http`
and `fs` modules.

## Running locally

```bash
node server.js
# then open http://localhost:3000
```

## Structure

```
index.html          Home
shop.html            Catalog with category/color filters + sorting
product.html         Product detail (?id=<product-id>&color=<color>)
about.html           Brand story
contact.html         Support form
assets/
  styles.css         Design system (suede frame, gold-leaf card, components)
  app.js             Product data, cart engine, page rendering, routing
  logo.jpg           Brand mark (referenced as a fallback favicon asset)
server.js            Zero-dependency static file server
```

## Editing the catalog

Products, prices, colors, and sizes live in the `PRODUCTS` array near the
top of `assets/app.js`. Garment art is generated from hand-coded SVG path
data in the same file (`SHAPES`), so new products render without needing
photography.

## Known placeholders to wire up before launch

- **Contact form** falls back to `mailto:` since no form backend is set.
  Set `CFG.formEndpoint` in `assets/app.js` to a service like Formspree to
  send directly instead.
- **Newsletter signup** only stores emails in the visitor's own browser
  (`localStorage`). Connect an email provider (Mailchimp, Klaviyo, etc.)
  before launch.
- **Checkout** button shows a placeholder message. Connect a real
  checkout provider (Shopify, Stripe) when ready.
