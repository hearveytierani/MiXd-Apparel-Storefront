/* =====================================================================
   MiXd Apperal — app.js
   Products · hand-drawn garment art · cart (localStorage) · page logic
   Works as separate .html pages OR as a single-file hash-routed preview.
   ===================================================================== */
(() => {
'use strict';

/* ---------- Config: edit these ---------- */
const CFG = {
  brand: 'MiXd Apperal',
  email: 'support@mixdapperal.com',   // shown on the Contact page + used by the form
  freeShip: 150,                      // free-shipping threshold ($)
  formEndpoint: '',                   // e.g. 'https://formspree.io/f/xxxx'. Empty = opens the visitor's email app (mailto)
  cartKey: 'mixd.cart.v1',
  newsKey: 'mixd.newsletter.v1',
};
const SPA = !!window.__MIXD_SPA__;

/* ---------- Tiny helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = n => '$' + (Number.isInteger(n) ? n : n.toFixed(2));
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* storage unavailable */ } },
};
const PAGE_FILE = { home: 'index.html', shop: 'shop.html', product: 'product.html', about: 'about.html', contact: 'contact.html' };
function link(page, params) {
  const q = params ? '?' + new URLSearchParams(params).toString() : '';
  return SPA ? '#/' + (page === 'home' ? '' : page) + q : PAGE_FILE[page] + q;
}

/* ---------- Data ---------- */
const COLORS = {
  ink:    { name: 'Ink Black',  hex: '#201A18' },
  bone:   { name: 'Bone',       hex: '#F3ECE2' },
  cognac: { name: 'Cognac',     hex: '#A36238' },
  saddle: { name: 'Saddle',     hex: '#63391F' },
  gold:   { name: 'Foil Gold',  hex: '#B38E46' },
};
const CATS = { tees: 'Tees', hoodies: 'Hoodies', accessories: 'Accessories' };
const SZ = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
const ONE = ['One Size'];

const PRODUCTS = [
  { id: 'static-tee',      name: 'Static Tee',              cat: 'tees',        type: 'tee',     art: 'bolt',   price: 48,  colors: ['bone', 'ink', 'cognac'],   sizes: SZ,  out: ['XXL'], badge: 'New',     feat: 1, added: 12, pop: 9, blurb: 'A boxy heavyweight tee with a hand-inked lightning strike across the chest.' },
  { id: 'crosswire-tee',   name: 'Cross-Wire Tee',          cat: 'tees',        type: 'tee',     art: 'x',      price: 52,  colors: ['ink', 'bone', 'saddle'],   sizes: SZ,  out: [],      badge: '',        feat: 0, added: 9,  pop: 8, blurb: 'The mixed-up X, radiating like a live wire. Printed thick, printed loud.' },
  { id: 'ink-bone-tee',    name: 'Ink & Bone Tee',          cat: 'tees',        type: 'tee',     art: 'scrawl', price: 46,  colors: ['bone', 'cognac'],          sizes: SZ,  out: ['XS'],  badge: '',        feat: 0, added: 6,  pop: 6, blurb: 'Loose marker scrawl, printed slightly off-register on purpose.' },
  { id: 'gold-leaf-tee',   name: 'Gold Leaf Tee',           cat: 'tees',        type: 'tee',     art: 'foil',   price: 58,  colors: ['ink', 'saddle'],           sizes: SZ,  out: [],      badge: 'Limited', feat: 0, added: 10, pop: 7, blurb: 'A pressed foil patch, crinkled and imperfect like real gold leaf.' },
  { id: 'bolt-hoodie',     name: 'Bolt Heavyweight Hoodie', cat: 'hoodies',     type: 'hoodie',  art: 'bolt',   price: 128, colors: ['ink', 'saddle', 'bone'],   sizes: SZ,  out: ['XS'],  badge: 'Limited', feat: 1, added: 11, pop: 10, blurb: 'Our flagship. Brushed-back heavyweight fleece with the hand-inked bolt front and centre.' },
  { id: 'signal-hoodie',   name: 'Signal X Hoodie',         cat: 'hoodies',     type: 'hoodie',  art: 'x',      price: 118, colors: ['ink', 'cognac'],           sizes: SZ,  out: [],      badge: '',        feat: 0, added: 8,  pop: 8, blurb: 'The MiXd X in full burst — rays and all — on a relaxed, roomy pullover.' },
  { id: 'wet-ink-hoodie',  name: 'Wet Ink Hoodie',          cat: 'hoodies',     type: 'hoodie',  art: 'wet',    price: 124, colors: ['saddle', 'bone', 'ink'],   sizes: SZ,  out: ['XXL'], badge: 'New',     feat: 1, added: 13, pop: 9, blurb: 'Dripping brush lettering, like the paint never dried. It did. It just looks like it didn’t.' },
  { id: 'no-rules-hoodie', name: 'No Rules Hoodie',         cat: 'hoodies',     type: 'hoodie',  art: 'scrawl', price: 122, colors: ['cognac', 'ink'],           sizes: SZ,  out: [],      badge: '',        feat: 0, added: 5,  pop: 5, blurb: 'Scribbled, circled, underlined twice. A hoodie with a point of view.' },
  { id: 'deckle-cap',      name: 'Deckle Dad Cap',          cat: 'accessories', type: 'cap',     art: 'x',      price: 38,  colors: ['ink', 'cognac', 'bone'],   sizes: ONE, out: [],      badge: '',        feat: 1, added: 7,  pop: 7, blurb: 'Washed six-panel cap with a small hand-inked X on the front.' },
  { id: 'static-beanie',   name: 'Static Beanie',           cat: 'accessories', type: 'beanie',  art: 'foil',   price: 34,  colors: ['ink', 'saddle', 'cognac'], sizes: ONE, out: [],      badge: '',        feat: 0, added: 4,  pop: 5, blurb: 'A ribbed cuff beanie with a foil MiXd patch that catches the light.' },
  { id: 'gold-leaf-tote',  name: 'Gold Leaf Tote',          cat: 'accessories', type: 'tote',    art: 'bolt',   price: 42,  colors: ['bone', 'ink'],             sizes: ONE, out: [],      badge: 'New',     feat: 0, added: 14, pop: 6, blurb: 'Heavy canvas tote, reinforced handles, one very loud bolt.' },
  { id: 'rebel-bandana',   name: 'Rebel Bandana',           cat: 'accessories', type: 'bandana', art: 'x',      price: 22,  colors: ['cognac', 'ink', 'gold'],   sizes: ONE, out: [],      badge: '',        feat: 0, added: 3,  pop: 4, blurb: 'Edge-to-edge X print. Wear it on your head, your bag, your wrist.' },
];
const byId = id => PRODUCTS.find(p => p.id === id);

const INFO = {
  tee: {
    material: 'Heavyweight combed-cotton jersey, garment-washed for a broken-in feel.',
    fit: 'Boxy through the body with a slightly dropped shoulder. True to size; size up for an oversized drape.',
    care: ['Machine wash cold, inside out, with like colors.', 'Gentle cycle. No bleach and no fabric softener (it dulls the ink).', 'Hang dry, or tumble on low.', 'Iron inside out on low heat. Never iron directly over the graphic or foil.'],
  },
  hoodie: {
    material: 'Brushed-back heavyweight cotton fleece with a double-layer hood and ribbed cuffs.',
    fit: 'Relaxed and roomy through the chest and shoulders. True to size; size down for a closer fit.',
    care: ['Machine wash cold, inside out, with like colors.', 'Gentle cycle. No bleach and no fabric softener.', 'Hang dry to keep the fleece soft and the print crisp.', 'Do not iron the graphic. Do not dry clean.'],
  },
  cap: {
    material: 'Washed cotton twill, six panels, with an adjustable strap.',
    fit: 'One size. Adjustable strap fits most heads.',
    care: ['Spot clean with a damp cloth and mild soap.', 'Do not machine wash; it can warp the brim.', 'Reshape and air dry.'],
  },
  beanie: {
    material: 'Soft ribbed knit with a foil-finish patch on the cuff.',
    fit: 'One size. Wear the cuff folded for a snug fit, or unfolded for slouch.',
    care: ['Hand wash cool with mild detergent.', 'Lay flat to dry. Do not wring.', 'Keep the foil patch away from direct heat.'],
  },
  tote: {
    material: 'Heavy cotton canvas with reinforced, double-stitched handles.',
    fit: 'One size. Roomy enough for a laptop, a hoodie, and a bad decision.',
    care: ['Spot clean, or wash cold on gentle and air dry.', 'Do not tumble dry.', 'Avoid ironing the print.'],
  },
  bandana: {
    material: 'Soft cotton twill, printed edge to edge.',
    fit: 'One size. Roughly 22 × 22 in.',
    care: ['Wash cold with like colors.', 'Air dry. Fades softly with wear, which is part of the look.', 'Iron on low, reverse side only.'],
  },
};

/* ---------- Colour helpers (garment shading) ---------- */
const rgb = h => { const n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
const mixHex = (a, b, t) => { const A = rgb(a), B = rgb(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join(''); };
const lum = h => { const [r, g, b] = rgb(h); return (0.299 * r + 0.587 * g + 0.114 * b) / 255; };
const shade = (h, a) => a < 0 ? mixHex(h, '#000000', -a) : mixHex(h, '#ffffff', a);
const palette = hex => {
  const dark = lum(hex) < .3, light = lum(hex) > .5;
  return {
    base: hex, dark: shade(hex, -.26), darker: shade(hex, -.5),
    line: dark ? shade(hex, .32) : shade(hex, -.55),
    ink: light ? '#201A18' : '#F3ECE2', acc: light ? '#B38E46' : '#E3BD6A',
  };
};

/* ---------- Hand-drawn garment illustrations (inline SVG) ---------- */
const ln = c => `stroke="${c.line}" stroke-width="3" stroke-linejoin="round"`;
const seam = c => `fill="none" stroke="${c.line}" stroke-width="2" opacity=".55" stroke-linecap="round"`;
const SHAPES = {
  tee: (c, v) => `
    <path d="M100 38 L62 52 L14 96 L48 132 L74 110 L74 262 Q74 270 82 270 L218 270 Q226 270 226 262 L226 110 L252 132 L286 96 L238 52 L200 38 Q150 ${v === 'back' ? 56 : 80} 100 38Z" fill="${c.base}" ${ln(c)}/>
    ${v === 'back' ? '' : `<path d="M100 38 Q150 12 200 38 Q150 80 100 38Z" fill="${c.darker}"/>`}
    <path d="M100 38 Q150 ${v === 'back' ? 56 : 80} 200 38" fill="none" stroke="${c.dark}" stroke-width="9" stroke-linecap="round"/>
    <path d="M74 110 Q82 70 100 40M226 110 Q218 70 200 40M74 254H226M120 205q10 20 4 46M182 190q-8 24 0 52" ${seam(c)}/>`,
  hoodie: (c, v) => `
    <path d="M96 74 L58 88 L20 196 L54 208 L76 148 L76 268 Q76 276 84 276 L216 276 Q224 276 224 268 L224 148 L246 208 L280 196 L242 88 L204 74 Q150 100 96 74Z" fill="${c.base}" ${ln(c)}/>
    <path d="M96 74 Q90 18 150 14 Q210 18 204 74 Q150 106 96 74Z" fill="${c.base}" ${ln(c)}/>
    ${v === 'back'
      ? `<path d="M150 16 Q142 60 150 96" ${seam(c)}/>`
      : `<path d="M112 70 Q116 36 150 32 Q184 36 188 70 Q150 94 112 70Z" fill="${c.darker}"/>
         <path d="M138 94 L134 142M162 94 L166 142" stroke="${c.ink}" stroke-width="3.5" stroke-linecap="round" fill="none"/>
         <circle cx="134" cy="145" r="4" fill="${c.acc}"/><circle cx="166" cy="145" r="4" fill="${c.acc}"/>
         <path d="M98 206H202L218 262H82Z" fill="none" stroke="${c.line}" stroke-width="2.5" opacity=".7" stroke-linejoin="round"/>`}
    <path d="M23 184L57 196M277 184L243 196M76 254H224" ${seam(c)}/>`,
  cap: c => `
    <path d="M52 172 Q52 66 150 62 Q248 66 248 172Z" fill="${c.base}" ${ln(c)}/>
    <path d="M150 64 Q108 96 102 170M150 64 Q192 96 198 170M52 172 Q150 158 248 172" ${seam(c)}/>
    <circle cx="150" cy="62" r="6" fill="${c.dark}" stroke="${c.line}" stroke-width="2"/>
    <path d="M40 172 Q150 148 260 172 Q292 214 150 226 Q8 214 40 172Z" fill="${c.dark}" ${ln(c)}/>
    <path d="M62 188 Q150 172 238 188" ${seam(c)}/>`,
  beanie: c => {
    const ribs = Array.from({ length: 12 }, (_, i) => { const x = 70 + i * 14.6, k = (x - 150) / 92; return `M${x.toFixed(1)} 194V${(246 + 9 * (1 - k * k)).toFixed(1)}`; }).join('');
    return `
    <path d="M66 196 Q60 58 150 56 Q240 58 234 196Z" fill="${c.base}" ${ln(c)}/>
    <path d="M94 84 Q118 64 146 62" fill="none" stroke="${shade(c.base, .25)}" stroke-width="4" stroke-linecap="round" opacity=".6"/>
    <path d="M58 190H242L246 246Q150 264 54 246Z" fill="${c.dark}" ${ln(c)}/>
    <path d="${ribs}" fill="none" stroke="${c.line}" stroke-width="2" opacity=".45"/>`;
  },
  tote: c => `
    <path d="M110 118 Q106 40 150 40 Q194 40 190 118" fill="none" stroke="${c.line}" stroke-width="12" stroke-linecap="round"/>
    <path d="M110 118 Q106 40 150 40 Q194 40 190 118" fill="none" stroke="${c.dark}" stroke-width="6" stroke-linecap="round"/>
    <path d="M78 112H222L232 268Q232 274 226 274H74Q68 274 68 268Z" fill="${c.base}" ${ln(c)}/>
    <path d="M76 128H224M72 258H228" ${seam(c)}/>`,
  bandana: c => `
    <path d="M150 26L276 150L150 274L24 150Z" fill="${c.base}" ${ln(c)}/>
    <path d="M150 54L246 150L150 246L54 150Z" fill="none" stroke="${c.ink}" stroke-width="2.5" stroke-dasharray="2 9" stroke-linecap="round" opacity=".7"/>
    <circle cx="150" cy="70" r="5" fill="${c.acc}"/><circle cx="230" cy="150" r="5" fill="${c.acc}"/><circle cx="150" cy="230" r="5" fill="${c.acc}"/><circle cx="70" cy="150" r="5" fill="${c.acc}"/>`,
};
const ART = {
  bolt:   c => `<use href="#bolt" x="-24" y="-56" width="48" height="96" style="color:${c.ink}"/><text y="72" text-anchor="middle" class="svg-marker" font-size="27" fill="${c.ink}">STATIC</text>`,
  x:      c => `<use href="#xburst" x="-64" y="-64" width="128" height="128" style="color:${c.ink};--hi:${c.acc}"/>`,
  wet:    c => `<text y="12" text-anchor="middle" class="svg-marker" font-size="50" fill="${c.ink}">MiXd</text><g stroke="${c.ink}" stroke-width="5" stroke-linecap="round" fill="none"><path d="M-40 22v20M-14 22v36M12 20v14M36 22v28"/></g><circle cx="-14" cy="62" r="4.5" fill="${c.ink}"/><circle cx="36" cy="54" r="4" fill="${c.ink}"/>`,
  scrawl: c => `<ellipse rx="58" ry="36" fill="none" stroke="${c.ink}" stroke-width="3.5" stroke-dasharray="150 12 60 8" transform="rotate(-5)"/><text y="8" text-anchor="middle" class="svg-marker" font-size="36" fill="${c.ink}">MiXd</text><text y="30" text-anchor="middle" class="svg-marker" font-size="14" fill="${c.acc}" letter-spacing="3">NO RULES</text>`,
  foil:   () => `<rect x="-36" y="-22" width="72" height="44" rx="3" fill="url(#foilg)" stroke="#201A18" stroke-width="2.5"/><text y="8" text-anchor="middle" class="svg-marker" font-size="24" fill="#201A18">MiXd</text>`,
};
const PLACE = { tee: [150, 152, .95], hoodie: [150, 152, .8], cap: [150, 118, .42], beanie: [150, 219, .75], tote: [150, 192, 1], bandana: [150, 150, 1.45] };
const FOCUS = { tee: [150, 150, 130], hoodie: [150, 150, 130], cap: [150, 118, 110], beanie: [150, 219, 100], tote: [150, 190, 130], bandana: [150, 150, 150] };

function garmentSVG(p, colorKey, view = 'front', opts = {}) {
  const c = palette(COLORS[colorKey].hex);
  const [px, py, ps] = PLACE[p.type];
  const [fx, fy, fs] = FOCUS[p.type];
  const back = view === 'back';
  const art = back ? 'x' : p.art;
  const boost = back && (p.type === 'tee' || p.type === 'hoodie') ? 1.35 : 1;
  const vb = view === 'detail' ? `${fx - fs / 2} ${fy - fs / 2} ${fs} ${fs}` : '0 0 300 300';
  const a11y = opts.label ? `role="img" aria-label="${esc(p.name)}, ${COLORS[colorKey].name}, ${view} view"` : 'aria-hidden="true" focusable="false"';
  return `<svg class="garment ${opts.cls || ''}" viewBox="${vb}" xmlns="http://www.w3.org/2000/svg" ${a11y}>
    <ellipse cx="150" cy="289" rx="86" ry="6" fill="#201A18" opacity=".15"/>
    <g filter="url(#roughSm)">${SHAPES[p.type](c, view)}</g>
    <g transform="translate(${px} ${py}) scale(${ps * boost}) rotate(-3)">${ART[art](c)}</g>
  </svg>`;
}

/* ---------- Product card ---------- */
function cardHTML(p, i = 0, colorKey) {
  const ck = colorKey && p.colors.includes(colorKey) ? colorKey : p.colors[0];
  const url = link('product', { id: p.id, color: ck });
  const r = [-.8, .7, -.5, .9][i % 4], tr = [-4, 3, -2, 5][i % 4];
  const names = p.colors.map(k => COLORS[k].name).join(', ');
  const dots = p.colors.map(k => `<i style="--c:${COLORS[k].hex}"></i>`).join('');
  const action = p.sizes.length === 1
    ? `<button class="btn btn--sm btn--block" type="button" data-add="${p.id}" data-color="${ck}" data-size="${p.sizes[0]}">Add to bag</button>`
    : `<a class="btn btn--sm btn--ghost btn--block" href="${url}">Choose size</a>`;
  return `<article class="card" style="--r:${r}deg;--tr:${tr}deg">
    <a class="card__img" href="${url}" tabindex="-1" aria-hidden="true"><svg class="ghost" viewBox="0 0 200 200" aria-hidden="true"><use href="#xburst"/></svg>${garmentSVG(p, ck, 'front')}${p.badge ? `<span class="sticker">${esc(p.badge)}</span>` : ''}</a>
    <div class="card__body">
      <p class="card__cat">${CATS[p.cat]}</p>
      <h3 class="card__name"><a href="${url}">${esc(p.name)}</a></h3>
      <div class="card__row"><span class="price">${fmt(p.price)}</span><span class="dots" role="img" aria-label="Colors: ${names}">${dots}</span></div>
      ${action}
    </div>
  </article>`;
}

/* ---------- Cart state ---------- */
let cart = [];
const lineKey = (id, color, size) => `${id}|${color}|${size}`;
function loadCart() {
  try {
    const a = JSON.parse(store.get(CFG.cartKey) || '[]');
    cart = Array.isArray(a) ? a.filter(i => byId(i.id) && COLORS[i.color] && i.qty > 0) : [];
  } catch (e) { cart = []; }
}
const saveCart = () => store.set(CFG.cartKey, JSON.stringify(cart));
const cartCount = () => cart.reduce((n, i) => n + i.qty, 0);
const cartSubtotal = () => cart.reduce((n, i) => n + byId(i.id).price * i.qty, 0);
function addToCart(id, color, size, qty = 1) {
  const key = lineKey(id, color, size), ex = cart.find(i => i.key === key);
  if (ex) ex.qty = Math.min(10, ex.qty + qty); else cart.push({ key, id, color, size, qty });
  saveCart(); renderCart();
}
function setQty(key, delta) {
  const i = cart.find(x => x.key === key); if (!i) return;
  i.qty += delta;
  if (i.qty <= 0) cart = cart.filter(x => x.key !== key); else i.qty = Math.min(10, i.qty);
  saveCart(); renderCart();
}
function removeLine(key) { cart = cart.filter(x => x.key !== key); saveCart(); renderCart(); }

function renderCart() {
  const n = cartCount(), sub = cartSubtotal();
  $$('[data-cart-count]').forEach(el => { el.textContent = n; el.hidden = n === 0; });
  const bag = $('.bag'); if (bag) bag.setAttribute('aria-label', `Open bag, ${n} item${n === 1 ? '' : 's'}`);
  const list = $('#cartList'); if (!list) return;
  list.innerHTML = cart.map(i => {
    const p = byId(i.id);
    return `<li class="line" data-key="${esc(i.key)}">
      <div class="line__img">${garmentSVG(p, i.color, 'front')}</div>
      <div>
        <a class="line__name" href="${link('product', { id: p.id, color: i.color })}">${esc(p.name)}</a>
        <p class="line__meta">${COLORS[i.color].name} · ${esc(i.size)} · ${fmt(p.price)}</p>
        <div class="qty" role="group" aria-label="Quantity for ${esc(p.name)}">
          <button type="button" data-qty="-1" aria-label="Decrease quantity">−</button>
          <span>${i.qty}</span>
          <button type="button" data-qty="1" aria-label="Increase quantity">+</button>
        </div>
      </div>
      <div class="line__end"><span>${fmt(p.price * i.qty)}</span><button type="button" class="link" data-remove>Remove</button></div>
    </li>`;
  }).join('');
  $('#cartEmpty').hidden = n > 0;
  list.hidden = n === 0;
  $('#cartFoot').hidden = n === 0;
  $('#cartSub').textContent = fmt(sub);
  const left = Math.max(0, CFG.freeShip - sub);
  $('#shipText').textContent = n === 0 ? `Free shipping over ${fmt(CFG.freeShip)}` : left > 0 ? `You’re ${fmt(left)} away from free shipping` : 'Free shipping unlocked ⚡';
  $('#shipBar').style.width = Math.min(100, (sub / CFG.freeShip) * 100) + '%';
}

/* ---------- Drawer, menu, toast ---------- */
let scroller, drawer, scrim, lastFocus = null, toastTimer;
function openCart() {
  lastFocus = document.activeElement;
  drawer.classList.add('is-open'); scrim.classList.add('is-open');
  drawer.setAttribute('aria-hidden', 'false'); scroller.classList.add('locked');
  setTimeout(() => $('#cartClose').focus(), 30);
}
function closeCart() {
  if (!drawer.classList.contains('is-open')) return;
  drawer.classList.remove('is-open'); scrim.classList.remove('is-open');
  drawer.setAttribute('aria-hidden', 'true'); scroller.classList.remove('locked');
  if (lastFocus && lastFocus.focus) lastFocus.focus();
}
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('is-show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('is-show'), 3200);
}
function setMenu(open) {
  const nav = $('.nav'); nav.classList.toggle('is-open', open);
  $('[data-nav-toggle]').setAttribute('aria-expanded', String(open));
}

function bindGlobal() {
  scroller = $('#scroller'); drawer = $('#cartDrawer'); scrim = $('#scrim');
  document.addEventListener('click', e => {
    const t = e.target;
    const add = t.closest('[data-add]');
    if (add) { addToCart(add.dataset.add, add.dataset.color, add.dataset.size); openCart(); return; }
    if (t.closest('[data-open-cart]')) { openCart(); return; }
    if (t.closest('[data-close-cart]') || t === scrim) { closeCart(); return; }
    if (t.closest('[data-nav-toggle]')) { setMenu(!$('.nav').classList.contains('is-open')); return; }
    if (t.closest('#checkoutBtn')) { toast('Demo store: connect Stripe or Shopify checkout here.'); return; }
    const line = t.closest('.line');
    if (line) {
      const q = t.closest('[data-qty]');
      if (q) { setQty(line.dataset.key, +q.dataset.qty); return; }
      if (t.closest('[data-remove]')) { removeLine(line.dataset.key); return; }
      if (t.closest('a')) closeCart();
    }
    if (t.closest('.nav__links a')) setMenu(false);
    if (t.closest('.drawer__empty a')) closeCart();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeCart(); setMenu(false); }
    if (e.key === 'Tab' && drawer.classList.contains('is-open')) {   // keep focus inside the open drawer
      const f = $$('button:not([disabled]), a[href]', drawer).filter(el => el.offsetParent !== null);
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  // let the mouse wheel scroll the page even when the pointer is over the suede border
  document.addEventListener('wheel', e => {
    if (!scroller.contains(e.target) && !drawer.contains(e.target)) scroller.scrollBy(0, e.deltaY);
  }, { passive: true });
  window.addEventListener('storage', e => { if (e.key === CFG.cartKey) { loadCart(); renderCart(); } });
}

/* ---------- Pages ---------- */
const PAGES = {};
const TITLES = {
  home: `${CFG.brand} — Wear the Mix`, shop: `Shop — ${CFG.brand}`, product: `Product — ${CFG.brand}`,
  about: `About — ${CFG.brand}`, contact: `Contact — ${CFG.brand}`,
};

PAGES.home = () => {
  const hp = byId('bolt-hoodie');
  $('#heroArt').innerHTML = `
    <svg class="burst" viewBox="0 0 200 200"><use href="#xburst"/></svg>
    <svg class="bolt-deco b1" viewBox="0 0 60 120"><use href="#bolt"/></svg>
    <svg class="bolt-deco b2" viewBox="0 0 60 120"><use href="#bolt"/></svg>
    ${garmentSVG(hp, 'ink', 'front', { cls: 'hero-garment' })}
    <span class="stamp">Drop 01<br>Limited<br>run</span>`;
  $('#featuredGrid').innerHTML = PRODUCTS.filter(p => p.feat).map((p, i) => cardHTML(p, i)).join('');
  bindNewsletter();
};

function bindNewsletter() {
  const f = $('#newsForm'); if (!f) return;
  f.addEventListener('submit', e => {
    e.preventDefault();
    const inp = f.elements.namedItem('email'), em = inp.value.trim(), msg = $('.msg', f);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em)) { msg.textContent = 'That email looks off. Try again?'; msg.className = 'msg bad'; inp.setAttribute('aria-invalid', 'true'); inp.focus(); return; }
    inp.removeAttribute('aria-invalid');
    let list = []; try { list = JSON.parse(store.get(CFG.newsKey) || '[]'); } catch (x) { /* ignore */ }
    if (!list.includes(em)) list.push(em);
    store.set(CFG.newsKey, JSON.stringify(list));   // demo only: swap for your email provider (Klaviyo, Mailchimp…)
    msg.textContent = 'You’re in. First dibs on every drop. ⚡'; msg.className = 'msg'; f.reset();
  });
}

PAGES.shop = q => {
  const st = { cat: CATS[q.cat] ? q.cat : 'all', colors: new Set(), sort: 'featured' };
  const sorters = {
    featured: (a, b) => b.pop - a.pop, new: (a, b) => b.added - a.added,
    'price-asc': (a, b) => a.price - b.price, 'price-desc': (a, b) => b.price - a.price,
    name: (a, b) => a.name.localeCompare(b.name),
  };
  $('#colorFilter').innerHTML = Object.entries(COLORS).map(([k, c]) => `<button type="button" class="swatch" data-color="${k}" style="--c:${c.hex}" aria-pressed="false" aria-label="${c.name}" title="${c.name}"></button>`).join('');
  const draw = () => {
    const list = PRODUCTS
      .filter(p => (st.cat === 'all' || p.cat === st.cat) && (!st.colors.size || p.colors.some(c => st.colors.has(c))))
      .sort(sorters[st.sort]);
    const pick = [...st.colors][0];
    $('#shopGrid').innerHTML = list.map((p, i) => cardHTML(p, i, [...st.colors].find(c => p.colors.includes(c)) || pick)).join('');
    $('#count').textContent = `${list.length} piece${list.length === 1 ? '' : 's'}`;
    $('#empty').hidden = list.length > 0;
    $$('.chip').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.cat === st.cat)));
    $$('#colorFilter .swatch').forEach(b => b.setAttribute('aria-pressed', String(st.colors.has(b.dataset.color))));
    $('#sort').value = st.sort;
  };
  $('#shop').addEventListener('click', e => {
    const chip = e.target.closest('.chip'), sw = e.target.closest('#colorFilter .swatch');
    if (chip) { st.cat = chip.dataset.cat; draw(); }
    if (sw) { const k = sw.dataset.color; st.colors.has(k) ? st.colors.delete(k) : st.colors.add(k); draw(); }
    if (e.target.closest('#clearFilters')) { st.cat = 'all'; st.colors.clear(); draw(); }
  });
  $('#sort').addEventListener('change', e => { st.sort = e.target.value; draw(); });
  draw();
};

PAGES.product = q => {
  const p = byId(q.id) || PRODUCTS[0];
  const info = INFO[p.type];
  const st = { color: p.colors.includes(q.color) ? q.color : p.colors[0], size: p.sizes.length === 1 ? p.sizes[0] : null, qty: 1, view: 'front' };
  const VIEWS = [['front', 'Front'], ['back', 'Back'], ['detail', 'Detail']];
  document.title = `${p.name} — ${CFG.brand}`;
  const isWear = p.type === 'tee' || p.type === 'hoodie';
  const related = PRODUCTS.filter(x => x.id !== p.id).sort((a, b) => (b.cat === p.cat) - (a.cat === p.cat) || b.pop - a.pop).slice(0, 4);

  $('#pdp').innerHTML = `
    <nav class="crumbs" aria-label="Breadcrumb"><a href="${link('home')}">Home</a> / <a href="${link('shop')}">Shop</a> / <a href="${link('shop', { cat: p.cat })}">${CATS[p.cat]}</a> / ${esc(p.name)}</nav>
    <div class="pdp">
      <div class="pdp__gallery">
        <div class="pdp__main" id="pdpMain"></div>
        <div class="pdp__thumbs" id="pdpThumbs"></div>
      </div>
      <div class="pdp__info">
        <p class="label">${CATS[p.cat]}${p.badge ? ' · ' + esc(p.badge) : ''}</p>
        <h1>${esc(p.name)}</h1>
        <p class="pdp__price">${fmt(p.price)}</p>
        <p>${esc(p.blurb)}</p>
        <fieldset class="opt"><legend>Color <b id="colorName"></b></legend>
          <div class="swatches" id="colors" role="radiogroup" aria-label="Color">
            ${p.colors.map(k => `<button type="button" class="swatch" role="radio" data-color="${k}" style="--c:${COLORS[k].hex}" aria-label="${COLORS[k].name}" title="${COLORS[k].name}"></button>`).join('')}
          </div></fieldset>
        <fieldset class="opt" id="sizeBox"><legend>Size <b id="sizeErr" role="alert"></b></legend>
          <div class="sizes" id="sizes" role="radiogroup" aria-label="Size">
            ${p.sizes.map(s => `<button type="button" class="size" role="radio" data-size="${s}" ${p.out.includes(s) ? 'disabled title="Sold out"' : ''}>${s}</button>`).join('')}
          </div></fieldset>
        <div class="buy">
          <div class="qty" role="group" aria-label="Quantity"><button type="button" data-q="-1" aria-label="Decrease quantity">−</button><span id="qtyVal">1</span><button type="button" data-q="1" aria-label="Increase quantity">+</button></div>
          <button type="button" class="btn btn--lg" id="addBtn">Add to bag</button>
        </div>
        <ul class="perks"><li>Free shipping over <span data-freeship></span></li><li>Small-batch run. When it’s gone, it’s gone</li></ul>
        <div class="acc">
          <details open><summary>Description</summary><p>${esc(p.blurb)} ${esc(info.material)}</p></details>
          <details><summary>Fit &amp; sizing</summary><p>${esc(info.fit)}</p>
            ${isWear ? `<table class="sizes-table"><caption class="sr">Approximate body chest measurements</caption><thead><tr><th>Size</th><th>Chest (in)</th></tr></thead><tbody>
              <tr><td>XS</td><td>32–34</td></tr><tr><td>S</td><td>35–37</td></tr><tr><td>M</td><td>38–40</td></tr><tr><td>L</td><td>41–43</td></tr><tr><td>XL</td><td>44–46</td></tr><tr><td>XXL</td><td>47–49</td></tr></tbody></table>` : ''}</details>
          <details><summary>Care guide</summary><ul>${info.care.map(c => `<li>${esc(c)}</li>`).join('')}</ul></details>
        </div>
      </div>
    </div>
    <section class="section" style="padding-top:1rem"><div class="section__head"><h2 class="display">More from the mix</h2></div>
      <div class="grid grid--4">${related.map((r, i) => cardHTML(r, i)).join('')}</div></section>`;

  const paint = () => {
    $('#pdpMain').innerHTML = `<svg class="ghost" viewBox="0 0 200 200" aria-hidden="true"><use href="#xburst"/></svg>` + garmentSVG(p, st.color, st.view, { label: true });
    $('#pdpThumbs').innerHTML = VIEWS.map(([v, l]) => `<button type="button" class="thumb" data-view="${v}" aria-pressed="${st.view === v}" aria-label="${l} view">${garmentSVG(p, st.color, v)}</button>`).join('');
    $('#colorName').textContent = '— ' + COLORS[st.color].name;
    $$('#colors .swatch').forEach(b => b.setAttribute('aria-checked', String(b.dataset.color === st.color)));
    $$('#sizes .size').forEach(b => b.setAttribute('aria-checked', String(b.dataset.size === st.size)));
    $('#qtyVal').textContent = st.qty;
  };
  $('#pdp').addEventListener('click', e => {
    const t = e.target;
    const v = t.closest('[data-view]'), c = t.closest('#colors [data-color]'), s = t.closest('#sizes [data-size]'), qb = t.closest('[data-q]');
    if (v) st.view = v.dataset.view;
    if (c) st.color = c.dataset.color;
    if (s && !s.disabled) { st.size = s.dataset.size; $('#sizeErr').textContent = ''; }
    if (qb) st.qty = Math.max(1, Math.min(10, st.qty + +qb.dataset.q));
    if (v || c || s || qb) paint();
    if (t.closest('#addBtn')) {
      if (!st.size) {
        $('#sizeErr').textContent = '— pick a size first';
        const box = $('#sizes'); box.classList.remove('shake'); void box.offsetWidth; box.classList.add('shake');
        const firstOpen = $$('#sizes .size:not([disabled])')[0]; if (firstOpen) firstOpen.focus();
        return;
      }
      addToCart(p.id, st.color, st.size, st.qty); openCart();
    }
  });
  paint();
};

PAGES.about = () => {};

PAGES.contact = () => {
  const f = $('#contactForm'); if (!f) return;
  $$('[data-email]').forEach(el => { el.textContent = CFG.email; if (el.tagName === 'A') el.href = 'mailto:' + CFG.email; });
  const setErr = (id, field, msg) => { $('#' + id).textContent = msg; field.setAttribute('aria-invalid', msg ? 'true' : 'false'); return !msg; };
  f.addEventListener('submit', async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(f)), el = n => f.elements.namedItem(n);
    const ok = [
      setErr('eName', el('name'), (d.name || '').trim() ? '' : 'Tell us your name.'),
      setErr('eEmail', el('email'), /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test((d.email || '').trim()) ? '' : 'Enter a valid email so we can reply.'),
      setErr('eMsg', el('message'), (d.message || '').trim().length >= 10 ? '' : 'A few more words, please (10+ characters).'),
    ];
    if (ok.includes(false)) { f.querySelector('[aria-invalid="true"]').focus(); return; }
    const status = $('#formStatus'), btn = $('button[type=submit]', f);
    const finish = viaMail => {
      f.hidden = true; $('#formDone').hidden = false;
      $('#doneNote').textContent = viaMail ? `Your email app should have opened with your message ready to send. If it didn’t, write to us at ${CFG.email}.` : 'We usually reply within 1–2 business days.';
      $('#formDone').focus();
    };
    if (d.website) return finish(false);   // honeypot: bots fill this in
    if (CFG.formEndpoint) {
      btn.disabled = true; status.textContent = 'Sending…';
      try {
        const r = await fetch(CFG.formEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(d) });
        if (!r.ok) throw new Error('bad status');
        finish(false);
      } catch (err) { status.textContent = `That didn’t send. Email us directly at ${CFG.email}.`; btn.disabled = false; }
    } else {
      const subject = `[${d.topic}] Message from ${d.name.trim()}`;
      const body = `${d.message.trim()}\n\n— ${d.name.trim()} <${d.email.trim()}>${d.order ? `\nOrder #: ${d.order.trim()}` : ''}`;
      finish(true);
      window.location.href = `mailto:${CFG.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    }
  });
};

/* ---------- Router / boot ---------- */
function parseRoute() {
  if (SPA) {
    const [p, q = ''] = location.hash.replace(/^#\/?/, '').split('?');
    const page = PAGES[p] ? p : 'home';
    return { page, query: Object.fromEntries(new URLSearchParams(q)) };
  }
  return { page: document.body.dataset.page || 'home', query: Object.fromEntries(new URLSearchParams(location.search)) };
}
function hydrate() {
  $$('[data-year]').forEach(el => { el.textContent = new Date().getFullYear(); });
  $$('[data-freeship]').forEach(el => { el.textContent = fmt(CFG.freeShip); });
  $$('[data-email]').forEach(el => { el.textContent = CFG.email; if (el.tagName === 'A') el.href = 'mailto:' + CFG.email; });
}
function route() {
  const { page, query } = parseRoute();
  if (SPA) {
    const tpl = $('#tpl-' + page);
    $('#main').innerHTML = tpl.innerHTML;
    document.body.dataset.page = page;
  }
  document.title = TITLES[page];
  $$('.nav__links a').forEach(a => {
    const on = a.dataset.nav === (page === 'product' ? 'shop' : page);
    on ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current');
  });
  hydrate();
  PAGES[page](query);
  hydrate();
  closeCart(); setMenu(false);
  scroller.scrollTop = 0;
  scroller.focus({ preventScroll: true });
}
function init() {
  loadCart();
  bindGlobal();
  scroller.setAttribute('tabindex', '-1');
  if (SPA) window.addEventListener('hashchange', route);
  renderCart();
  route();
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
